"use strict";
(self["webpackChunk_datalayer_jupyter_traitlets"] = self["webpackChunk_datalayer_jupyter_traitlets"] || []).push([["icons_lib_index_js"],{

/***/ "../../../../icons/lib/Icon.js":
/*!*************************************!*\
  !*** ../../../../icons/lib/Icon.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");

const DEFAULT_SIZE = 16;
const DEFAULT_VIEWBOX = "0 0 24 24";
const Icon = ({ children, className, onClick, theme, viewBox, ...rest }) => {
    const size = rest.size ? rest.size + "px" : `${DEFAULT_SIZE}px`;
    let fill = "currentColor";
    if (rest.color) {
        fill = rest.color;
    }
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: viewBox ?? DEFAULT_VIEWBOX, width: size, height: size, className: className, fill: fill, onClick: onClick, ...rest.outerProps, style: {
            display: "inline-block",
            userSelect: "none",
            verticalAlign: "text-bottom",
            overflow: "visible"
            //        fill: "currentColor",
            //        ...rest.outerProps?.style
        }, children: children }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Icon);


/***/ }),

/***/ "../../../../icons/lib/icons/AcademicCapIcon.js":
/*!******************************************************!*\
  !*** ../../../../icons/lib/icons/AcademicCapIcon.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const AcademicCapIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "4 4 16 16", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M17,13.5977511 L17,17 C17,18.6568542 14.7614237,20 12,20 C9.32225576,20 7.13615141,18.7370236 7.00611913,17.1497303 L7,17 L7,13.5977511 L10.0154442,15.3212215 C11.2451749,16.0239247 12.7548251,16.0239247 13.9845558,15.3212215 L17,13.5977511 Z M11.0077221,4.41526482 C11.6225875,4.0639132 12.3774125,4.0639132 12.9922779,4.41526482 L12.9922779,4.41526482 L19.4961389,8.13175686 C20.1679537,8.515651 20.1679537,9.484349 19.4961389,9.86824314 L19.4961389,9.86824314 L12.9922779,13.5847352 C12.3774125,13.9360868 11.6225875,13.9360868 11.0077221,13.5847352 L11.0077221,13.5847352 L4.50386106,9.86824314 C3.83204631,9.484349 3.83204631,8.515651 4.50386106,8.13175686 L4.50386106,8.13175686 Z" }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AcademicCapIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/CollaborateIcon.js":
/*!******************************************************!*\
  !*** ../../../../icons/lib/icons/CollaborateIcon.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const CollaborateIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 32 32", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "currentColor", d: "M6 21v-1H4v1a7 7 0 0 0 7 7h3v-2h-3a5 5 0 0 1-5-5zm18-10v1h2v-1a7 7 0 0 0-7-7h-3v2h3a5 5 0 0 1 5 5zm-13 0H5a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zm-3-1a4 4 0 1 0-4-4a4 4 0 0 0 4 4zm0-6a2 2 0 1 1-2 2a2 2 0 0 1 2-2zm19 21h-6a3 3 0 0 0-3 3v2h2v-2a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h2v-2a3 3 0 0 0-3-3zm-7-5a4 4 0 1 0 4-4a4 4 0 0 0-4 4zm6 0a2 2 0 1 1-2-2a2 2 0 0 1 2 2z" }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CollaborateIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/DaskLogoIcon.js":
/*!***************************************************!*\
  !*** ../../../../icons/lib/icons/DaskLogoIcon.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const DaskLogoIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 512 512", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", { children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#FFC11E", d: "M143.71,157.61l126.5-72.99c1.25-0.72,2.02-2.05,2.02-3.5l0.01-43.77c0-6.48-2.66-12.9-7.83-16.81\n          c-6.69-5.06-15.28-5.56-22.33-1.48L65.13,121.17c-6.22,3.59-10.06,10.23-10.06,17.41L55,369.18c0,6.47,2.65,12.89,7.81,16.81\n          c6.68,5.07,15.29,5.57,22.35,1.49l37.48-21.62c1.25-0.72,2.02-2.05,2.02-3.5l0.05-171.85C124.71,176.93,131.95,164.4,143.71,157.61\n          z" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#EF1161", d: "M446.95,124.53c-3.15-1.82-6.61-2.73-10.06-2.73c-3.45,0-6.9,0.91-10.05,2.73l-176.96,102.1\n          c-6.2,3.58-10.06,10.25-10.06,17.41l-0.07,231.47c0,7.27,3.76,13.78,10.05,17.42c6.3,3.64,13.81,3.64,20.11,0l176.95-102.11\n          c6.2-3.58,10.06-10.25,10.06-17.41L457,141.95C457,134.68,453.24,128.16,446.95,124.53z" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#FC6E6B", d: "M240.95,211.14l116.78-67.38c1.25-0.72,2.02-2.05,2.02-3.5l0.02-50.98c0-6.48-2.66-12.9-7.83-16.81\n          c-6.69-5.06-15.27-5.55-22.33-1.48l-48.43,27.95L152.64,173.1c-6.22,3.59-10.06,10.23-10.06,17.41l-0.05,174.18l-0.02,56.41\n          c0,6.48,2.65,12.89,7.81,16.81c6.69,5.07,15.29,5.57,22.35,1.49l47.2-27.24c1.25-0.72,2.02-2.05,2.02-3.5l0.05-164.64\n          C221.95,230.46,229.19,217.92,240.95,211.14z" })] }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DaskLogoIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/DatalayerLogoBlackIcon.js":
/*!*************************************************************!*\
  !*** ../../../../icons/lib/icons/DatalayerLogoBlackIcon.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const DatalayerLogoBlackIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 16 16", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "0" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "6.4" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "12.8" })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DatalayerLogoBlackIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/DatalayerLogoColorIcon.js":
/*!*************************************************************!*\
  !*** ../../../../icons/lib/icons/DatalayerLogoColorIcon.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const DatalayerLogoWhiteIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 16 16", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "0", style: { fill: "#E26D6DFF" } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "6.4", style: { fill: "#F9CB07FF" } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "12.8", style: { fill: "#49B3D9FF" } })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DatalayerLogoWhiteIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/DatalayerLogoGreenIcon.js":
/*!*************************************************************!*\
  !*** ../../../../icons/lib/icons/DatalayerLogoGreenIcon.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const DatalayerLogoWhiteIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 16 16", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "0", style: { fill: "#2ECC71" } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "6.4", style: { fill: "#1ABC9C" } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "12.8", style: { fill: "#16A085" } })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DatalayerLogoWhiteIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/DatalayerLogoIcon.js":
/*!********************************************************!*\
  !*** ../../../../icons/lib/icons/DatalayerLogoIcon.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const DatalayerLogoIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 16 16", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { fill: "#FFC11E", width: "16", height: "3.2", x: "0", y: "0" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { fill: "#FC6E6B", width: "16", height: "3.2", x: "0", y: "6.4" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { fill: "#EF1161", width: "16", height: "3.2", x: "0", y: "12.8" })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DatalayerLogoIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/DatalayerLogoWhiteIcon.js":
/*!*************************************************************!*\
  !*** ../../../../icons/lib/icons/DatalayerLogoWhiteIcon.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const DatalayerLogoWhiteIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 16 16", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "0", style: { fill: "#FFFFFF" } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "6.4", style: { fill: "#FFFFFF" } }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("rect", { width: "16", height: "3.2", x: "0", y: "12.8", style: { fill: "#FFFFFF" } })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DatalayerLogoWhiteIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/PyTorchLogoIcon.js":
/*!******************************************************!*\
  !*** ../../../../icons/lib/icons/PyTorchLogoIcon.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const PyTorchLogoIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 64 64", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", { transform: "matrix(2.21262 0 0 2.21262 -39.453867 -1.770085)", fill: "#ee4c2c", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M40.8 9.3l-2.1 2.1c3.5 3.5 3.5 9.2 0 12.7s-9.2 3.5-12.7 0-3.5-9.2 0-12.7l5.6-5.6.7-.8V.8l-8.5 8.5a11.89 11.89 0 0 0 0 16.9 11.89 11.89 0 0 0 16.9 0c4.8-4.7 4.8-12.3.1-16.9z" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("circle", { r: "1.6", cy: "7.1", cx: "36.6" })] }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PyTorchLogoIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/ReactJsLogoIcon.js":
/*!******************************************************!*\
  !*** ../../../../icons/lib/icons/ReactJsLogoIcon.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const ReactJsLogoIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 -1 23 23", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M18.9107,6.63257h0q-.36721-.126-.74042-.2333.06187-.25141.11441-.505c.56045-2.72064.194-4.91237-1.05739-5.63386-1.1998-.692-3.1621.02952-5.14394,1.75414q-.29293.2555-.57267.52554-.18727-.17951-.3811-.352C9.05257.3439,6.97066-.43316,5.72058.29046,4.52191.98436,4.16686,3.04489,4.67144,5.62322q.0753.383.17.76179c-.29458.08367-.57908.17284-.85127.26771C1.55514,7.50165,0,8.83225,0,10.21231c0,1.42546,1.66935,2.8552,4.20575,3.722q.3085.10494.62193.19442-.10179.408-.18068.82114c-.48106,2.53354-.10535,4.54521,1.09017,5.23484,1.23481.712,3.30725-.01985,5.32533-1.78387q.23926-.20917.47994-.44238.3029.29225.62173.56727c1.95477,1.68207,3.88531,2.36132,5.07982,1.66986,1.23369-.71416,1.63454-2.87525,1.114-5.50459q-.05955-.30124-.13792-.61481.21834-.06443.42772-.13355C21.28454,13.06915,23,11.65681,23,10.21232,23,8.82726,21.39478,7.48771,18.9107,6.63257ZM12.7284,2.75581C14.42646,1.278,16.01346.69457,16.73657,1.1116h0c.77014.44421,1.06971,2.2354.5858,4.58441q-.04758.22953-.10342.45724a23.53752,23.53752,0,0,0-3.07527-.48584A23.08128,23.08128,0,0,0,12.1995,3.24094Q12.45788,2.99184,12.7284,2.75581ZM6.79111,11.39124q.312.60265.65207,1.19013.34692.59911.7221,1.18117a20.92168,20.92168,0,0,1-2.11967-.3408C6.24867,12.766,6.49887,12.08443,6.79111,11.39124ZM6.79,9.08041c-.28613-.67863-.53093-1.34586-.73085-1.99019.65624-.14688,1.356-.26689,2.08516-.358q-.36611.571-.7051,1.15877Q7.10076,8.478,6.79,9.08041Zm.52228,1.15552q.45411-.94517.9783-1.8542v.0002q.52369-.90857,1.11521-1.77542c.684-.05171,1.38536-.07879,2.09432-.07879.71212,0,1.41437.02728,2.09819.0794q.58514.86487,1.10818,1.76941.52565.90635.99153,1.84545-.46083.94817-.98828,1.86173h-.0001q-.52261.90786-1.1034,1.7803c-.6824.04876-1.3876.0739-2.10623.0739-.71568,0-1.41193-.02229-2.08241-.06575q-.59555-.86995-1.12406-1.78305Q7.76789,11.18148,7.31227,10.23593Zm8.24853,2.33862q.347-.60182.667-1.21863h0a20.86671,20.86671,0,0,1,.77238,2.02327,20.85164,20.85164,0,0,1-2.14552.36573Q15.21935,13.16682,15.5608,12.57455Zm.65767-3.49343q-.31883-.605-.66163-1.19684h0q-.33727-.58258-.6994-1.15022c.7339.09263,1.437.21579,2.09717.36654A20.95909,20.95909,0,0,1,16.21847,9.08112ZM11.511,3.94359a21.01288,21.01288,0,0,1,1.3535,1.63393q-1.35843-.06419-2.7184-.00061C10.593,4.98765,11.0507,4.44022,11.511,3.94359ZM6.21284,1.14081c.76953-.44543,2.47095.18973,4.26428,1.782.11461.10179.22974.20836.34507.3186A23.54542,23.54542,0,0,0,8.86294,5.66608a24.008,24.008,0,0,0-3.06916.477q-.088-.35228-.15808-.70866v.0001C5.20339,3.22536,5.49044,1.559,6.21284,1.14081ZM5.09132,13.18233q-.286-.08187-.56778-.17773A8.32371,8.32371,0,0,1,1.841,11.57955a2.03072,2.03072,0,0,1-.85849-1.36724c0-.83742,1.24865-1.90571,3.33117-2.63178q.39208-.1361.79162-.24908a23.56455,23.56455,0,0,0,1.121,2.90478A23.92247,23.92247,0,0,0,5.09132,13.18233ZM10.41594,17.661a8.32161,8.32161,0,0,1-2.57467,1.61184h-.0001a2.03042,2.03042,0,0,1-1.61306.06067c-.72556-.41836-1.02706-2.03376-.61573-4.20035q.07337-.38407.168-.76363a23.10444,23.10444,0,0,0,3.0995.44869,23.90954,23.90954,0,0,0,1.97431,2.43929Q10.64,17.46459,10.41594,17.661Zm1.12223-1.11053c-.46569-.50253-.93015-1.05831-1.38383-1.65612q.66051.026,1.34566.02606.70326,0,1.38841-.03084A20.89425,20.89425,0,0,1,11.53817,16.55045Zm5.96651,1.367a2.03039,2.03039,0,0,1-.753,1.4278c-.72485.41958-2.275-.12581-3.94659-1.56431q-.2875-.24735-.57837-.52727a23.08914,23.08914,0,0,0,1.9279-2.448,22.93647,22.93647,0,0,0,3.11507-.48014q.07024.284.12449.55638h0A8.32,8.32,0,0,1,17.50468,17.91749Zm.83417-4.90739h-.0001c-.12571.04163-.25478.08184-.38629.12082a23.06121,23.06121,0,0,0-1.16468-2.91373,23.05112,23.05112,0,0,0,1.11938-2.87128c.23524.0682.46365.14.68372.21579,2.12842.73258,3.42665,1.81593,3.42665,2.65061C22.01753,11.10145,20.61538,12.25574,18.33885,13.0101Z", fill: "#61dafb" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M11.5,8.1585a2.05386,2.05386,0,1,1-2.05381,2.05381A2.05381,2.05381,0,0,1,11.5,8.1585", fill: "#61dafb" })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReactJsLogoIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/SchoolIcon.js":
/*!*************************************************!*\
  !*** ../../../../icons/lib/icons/SchoolIcon.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const SchoolIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "2 2 44 44", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", { fill: "none", stroke: "currentColor", "stroke-width": "3", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { "stroke-linejoin": "round", d: "M4 33a2 2 0 0 1 2-2h6v-7l12-8l12 8v7h6a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4V33Z" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { "stroke-linecap": "round", d: "M24 6v10" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { "stroke-linecap": "round", "stroke-linejoin": "round", d: "M36 12V6s-1.5 3-6 0s-6 0-6 0v6s1.5-3 6 0s6 0 6 0Zm-8 32V31h-8v13m-2 0h12" })] }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SchoolIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/StudentIcon.js":
/*!**************************************************!*\
  !*** ../../../../icons/lib/icons/StudentIcon.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const StudentIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 190 190", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M 186.92157,31.082422 98.312115,0.36094054 a 7.8456282,8.1603935 0 0 0 -4.615072,0 L 5.1798919,31.082422 H 4.995289 L 4.0722739,31.562445 H 3.979972 l -0.9230151,0.576029 c 0,0.096 -0.092302,0.096 -0.184603,0.192009 l -0.7384121,0.672032 -0.6461105,0.768037 c 0,0.096 -0.092302,0.096 -0.092302,0.192009 l -0.55380912,0.864042 c 0,0.096 0,0.096 -0.0923015,0.192009 l -0.36920604,0.864041 -0.27690452,1.056052 v 0.288014 A 3.4151558,3.5521713 0 0 0 0.0110076,38.378774 v 76.803696 a 7.3841208,7.6803705 0 0 0 14.7682414,0 V 49.035288 l 31.013306,10.752519 a 58.334554,60.674926 0 0 0 -8.860945,32.35356 59.072966,61.442963 0 0 0 27.690453,52.034503 88.70175,92.260449 0 0 0 -42.920201,35.90573 7.4764221,7.7763749 0 0 0 2.215235,10.65652 7.2918191,7.5843657 0 0 0 10.153167,-2.2081 73.841206,76.803703 0 0 1 123.868636,0 7.3841206,7.6803703 0 0 0 6.1842,3.45616 6.9226131,7.2003472 0 0 0 3.96896,-1.24806 7.4764221,7.7763749 0 0 0 2.21524,-10.65652 88.70175,92.260449 0 0 0 -42.9202,-35.90573 59.072966,61.442963 0 0 0 27.69045,-52.034503 58.334554,60.674926 0 0 0 -8.86096,-32.35356 l 40.70498,-14.11268 a 7.3841206,7.6803703 0 0 0 0,-14.592705 z M 140.3093,92.141367 a 44.304728,46.082226 0 0 1 -88.609448,0 44.858533,46.65825 0 0 1 8.584039,-27.36132 l 33.413152,11.616561 a 7.3841206,7.6803703 0 0 0 4.615072,0 L 131.72526,64.780047 a 44.858533,46.65825 0 0 1 8.58404,27.36132 z m -8.58404,-43.490098 h -0.0923 L 96.00458,61.035867 60.376194,48.651269 h -0.0923 L 30.747409,38.378774 96.00458,15.721681 161.26175,38.378774 Z" }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StudentIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/TensorFlowLogoIcon.js":
/*!*********************************************************!*\
  !*** ../../../../icons/lib/icons/TensorFlowLogoIcon.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const TensorFlowLogoIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 32 32", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("g", { transform: "translate(-77.942529,-177.00005)", id: "layer1", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", { id: "g4550", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { style: { fill: "#e55b2d", fillOpacity: 1 }, d: "m 360.04883,687.87305 v 18.89843 l 32.73047,18.89844 v -18.89844 z m -65.46289,18.89843 v 18.89844 l 16.36523,9.44727 V 716.2207 Z m 49.0957,9.44922 -16.36523,9.44922 v 56.69141 l 16.36523,9.44922 v -37.79493 l 16.36719,9.44922 v -18.89843 l -16.36719,-9.44922 z", transform: "scale(0.26458333)", id: "path4508" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { style: { fill: "#ed8e24", fillOpacity: 1 }, d: "m 360.04883,687.87305 -49.09766,28.34765 v 18.89649 l 32.73047,-18.89649 v 18.89649 l 16.36719,-9.44727 z m 49.09765,9.44922 -16.36718,9.44921 v 18.89844 l 16.36718,-9.44922 z m -32.73242,37.79492 -16.36523,9.44922 v 18.89843 l 16.36523,-9.44922 z m -16.36523,28.34765 -16.36719,-9.44922 v 37.79493 l 16.36719,-9.44922 z", transform: "scale(0.26458333)", id: "path4491" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { style: { fill: "#f8bf3c", fillOpacity: 1 }, d: "m 360.04883,668.97656 -65.46289,37.79492 16.36523,9.44922 49.09766,-28.34765 32.73047,18.89843 16.36718,-9.44921 z m 0,56.69336 -16.36719,9.44727 16.36719,9.44922 16.36523,-9.44922 z", transform: "scale(0.26458333)", id: "path4506" })] }) }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TensorFlowLogoIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/TwitterIcon.js":
/*!**************************************************!*\
  !*** ../../../../icons/lib/icons/TwitterIcon.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const TwitterIcon = (props) => {
    const color = props.color || "#1DA1F2";
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 24 24", color: color, children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { d: "M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" }) }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TwitterIcon);


/***/ }),

/***/ "../../../../icons/lib/icons/WebRTCIcon.js":
/*!*************************************************!*\
  !*** ../../../../icons/lib/icons/WebRTCIcon.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "../../../../../node_modules/react/jsx-runtime.js");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Icon */ "../../../../icons/lib/Icon.js");


const WebRTCIcon = (props) => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Icon__WEBPACK_IMPORTED_MODULE_1__["default"], { ...props, viewBox: "0 0 256 249", children: [(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#F60", d: "M142.077 191.087c0 31.806-25.782 57.592-57.588 57.592c-31.81 0-57.593-25.786-57.593-57.592c0-31.806 25.782-57.592 57.593-57.592c31.806 0 57.588 25.786 57.588 57.592" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#FC0", d: "M255.98 110.459c0 31.802-25.782 57.592-57.588 57.592c-31.81 0-57.592-25.79-57.592-57.592c0-31.807 25.781-57.597 57.592-57.597c31.806 0 57.588 25.79 57.588 57.597" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#0089CC", d: "M115.2 109.18c0 31.802-25.781 57.593-57.592 57.593c-31.802 0-57.588-25.79-57.588-57.592c0-31.807 25.786-57.597 57.588-57.597c31.81 0 57.592 25.79 57.592 57.597" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#009939", d: "M230.386 191.087c0 31.806-25.782 57.592-57.597 57.592c-31.802 0-57.588-25.786-57.588-57.592c0-31.806 25.786-57.592 57.588-57.592c31.815 0 57.597 25.786 57.597 57.592" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#BF0000", d: "M185.592 57.985c0 31.806-25.786 57.592-57.592 57.592c-31.806 0-57.592-25.786-57.592-57.592C70.408 26.179 96.194.392 128 .392c31.806 0 57.592 25.787 57.592 57.593" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#FC0007", d: "M140.799 110.458c0 1.212.105 2.398.181 3.593c25.546-5.894 44.61-28.733 44.61-56.068c0-1.212-.105-2.402-.18-3.597c-25.546 5.897-44.611 28.737-44.611 56.072" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#1CD306", d: "M148.397 138.975c9.925 17.352 28.576 29.075 49.997 29.075c8.73 0 16.976-2.001 24.393-5.48c-9.92-17.35-28.572-29.074-49.997-29.074c-8.73 0-16.976 2-24.393 5.48" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#0F7504", d: "M115.2 191.087c0 14.071 5.058 26.947 13.442 36.948c8.376-10 13.434-22.877 13.434-36.948c0-14.07-5.058-26.947-13.434-36.948c-8.384 10.001-13.442 22.877-13.442 36.948" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#0C5E87", d: "M34.807 162.057a57.324 57.324 0 0 0 22.801 4.716c21.21 0 39.688-11.496 49.685-28.564a57.336 57.336 0 0 0-22.801-4.711c-21.21 0-39.692 11.495-49.685 28.56" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#6B0001", d: "M70.655 53.126c-.136 1.604-.25 3.217-.25 4.86c0 27.313 19.036 50.132 44.552 56.05c.13-1.604.245-3.217.245-4.855c0-27.314-19.032-50.14-44.547-56.055" }), (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("path", { fill: "#FFF", d: "M76.03 183.96h-9.009c-7.953 0-14.42-6.446-14.42-14.379V88.035c0-7.932 6.467-14.383 14.42-14.383H179.99c7.954 0 14.417 6.45 14.417 14.383v81.546c0 7.933-6.463 14.38-14.417 14.38h-38.484L64.29 221.81l11.74-37.85Z" })] }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WebRTCIcon);


/***/ }),

/***/ "../../../../icons/lib/index.js":
/*!**************************************!*\
  !*** ../../../../icons/lib/index.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AcademicCapIcon": () => (/* reexport safe */ _icons_AcademicCapIcon__WEBPACK_IMPORTED_MODULE_1__["default"]),
/* harmony export */   "CollaborateIcon": () => (/* reexport safe */ _icons_CollaborateIcon__WEBPACK_IMPORTED_MODULE_2__["default"]),
/* harmony export */   "DaskLogoIcon": () => (/* reexport safe */ _icons_DaskLogoIcon__WEBPACK_IMPORTED_MODULE_3__["default"]),
/* harmony export */   "DatalayerLogoBlackIcon": () => (/* reexport safe */ _icons_DatalayerLogoBlackIcon__WEBPACK_IMPORTED_MODULE_5__["default"]),
/* harmony export */   "DatalayerLogoColorIcon": () => (/* reexport safe */ _icons_DatalayerLogoColorIcon__WEBPACK_IMPORTED_MODULE_6__["default"]),
/* harmony export */   "DatalayerLogoGreenIcon": () => (/* reexport safe */ _icons_DatalayerLogoGreenIcon__WEBPACK_IMPORTED_MODULE_7__["default"]),
/* harmony export */   "DatalayerLogoIcon": () => (/* reexport safe */ _icons_DatalayerLogoIcon__WEBPACK_IMPORTED_MODULE_4__["default"]),
/* harmony export */   "DatalayerLogoWhiteIcon": () => (/* reexport safe */ _icons_DatalayerLogoWhiteIcon__WEBPACK_IMPORTED_MODULE_8__["default"]),
/* harmony export */   "OrganisationIcon": () => (/* reexport safe */ _primer_octicons_react__WEBPACK_IMPORTED_MODULE_9__.OrganizationIcon),
/* harmony export */   "PyTorchLogoIcon": () => (/* reexport safe */ _icons_PyTorchLogoIcon__WEBPACK_IMPORTED_MODULE_10__["default"]),
/* harmony export */   "ReactJsLogoIcon": () => (/* reexport safe */ _icons_ReactJsLogoIcon__WEBPACK_IMPORTED_MODULE_11__["default"]),
/* harmony export */   "SchoolIcon": () => (/* reexport safe */ _icons_SchoolIcon__WEBPACK_IMPORTED_MODULE_12__["default"]),
/* harmony export */   "StudentIcon": () => (/* reexport safe */ _icons_StudentIcon__WEBPACK_IMPORTED_MODULE_13__["default"]),
/* harmony export */   "TensorFlowLogoIcon": () => (/* reexport safe */ _icons_TensorFlowLogoIcon__WEBPACK_IMPORTED_MODULE_14__["default"]),
/* harmony export */   "TwitterIcon": () => (/* reexport safe */ _icons_TwitterIcon__WEBPACK_IMPORTED_MODULE_15__["default"]),
/* harmony export */   "WebRTCIcon": () => (/* reexport safe */ _icons_WebRTCIcon__WEBPACK_IMPORTED_MODULE_16__["default"]),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Icon */ "../../../../icons/lib/Icon.js");
/* harmony import */ var _icons_AcademicCapIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./icons/AcademicCapIcon */ "../../../../icons/lib/icons/AcademicCapIcon.js");
/* harmony import */ var _icons_CollaborateIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./icons/CollaborateIcon */ "../../../../icons/lib/icons/CollaborateIcon.js");
/* harmony import */ var _icons_DaskLogoIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./icons/DaskLogoIcon */ "../../../../icons/lib/icons/DaskLogoIcon.js");
/* harmony import */ var _icons_DatalayerLogoIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./icons/DatalayerLogoIcon */ "../../../../icons/lib/icons/DatalayerLogoIcon.js");
/* harmony import */ var _icons_DatalayerLogoBlackIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./icons/DatalayerLogoBlackIcon */ "../../../../icons/lib/icons/DatalayerLogoBlackIcon.js");
/* harmony import */ var _icons_DatalayerLogoColorIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./icons/DatalayerLogoColorIcon */ "../../../../icons/lib/icons/DatalayerLogoColorIcon.js");
/* harmony import */ var _icons_DatalayerLogoGreenIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./icons/DatalayerLogoGreenIcon */ "../../../../icons/lib/icons/DatalayerLogoGreenIcon.js");
/* harmony import */ var _icons_DatalayerLogoWhiteIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./icons/DatalayerLogoWhiteIcon */ "../../../../icons/lib/icons/DatalayerLogoWhiteIcon.js");
/* harmony import */ var _primer_octicons_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @primer/octicons-react */ "webpack/sharing/consume/default/@primer/octicons-react/@primer/octicons-react?1ee7");
/* harmony import */ var _primer_octicons_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_primer_octicons_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _icons_PyTorchLogoIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./icons/PyTorchLogoIcon */ "../../../../icons/lib/icons/PyTorchLogoIcon.js");
/* harmony import */ var _icons_ReactJsLogoIcon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./icons/ReactJsLogoIcon */ "../../../../icons/lib/icons/ReactJsLogoIcon.js");
/* harmony import */ var _icons_SchoolIcon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./icons/SchoolIcon */ "../../../../icons/lib/icons/SchoolIcon.js");
/* harmony import */ var _icons_StudentIcon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./icons/StudentIcon */ "../../../../icons/lib/icons/StudentIcon.js");
/* harmony import */ var _icons_TensorFlowLogoIcon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./icons/TensorFlowLogoIcon */ "../../../../icons/lib/icons/TensorFlowLogoIcon.js");
/* harmony import */ var _icons_TwitterIcon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./icons/TwitterIcon */ "../../../../icons/lib/icons/TwitterIcon.js");
/* harmony import */ var _icons_WebRTCIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./icons/WebRTCIcon */ "../../../../icons/lib/icons/WebRTCIcon.js");


















const icons = Object.assign(_Icon__WEBPACK_IMPORTED_MODULE_0__["default"], {
    AcademicCap: _icons_AcademicCapIcon__WEBPACK_IMPORTED_MODULE_1__["default"],
    Collaborate: _icons_CollaborateIcon__WEBPACK_IMPORTED_MODULE_2__["default"],
    DaskLogo: _icons_DaskLogoIcon__WEBPACK_IMPORTED_MODULE_3__["default"],
    DatalayerLogo: _icons_DatalayerLogoIcon__WEBPACK_IMPORTED_MODULE_4__["default"],
    DatalayerLogoBlack: _icons_DatalayerLogoBlackIcon__WEBPACK_IMPORTED_MODULE_5__["default"],
    DatalayerLogoColor: _icons_DatalayerLogoColorIcon__WEBPACK_IMPORTED_MODULE_6__["default"],
    DatalayerLogoGreen: _icons_DatalayerLogoGreenIcon__WEBPACK_IMPORTED_MODULE_7__["default"],
    DatalayerLogoWhite: _icons_DatalayerLogoWhiteIcon__WEBPACK_IMPORTED_MODULE_8__["default"],
    Organisation: _primer_octicons_react__WEBPACK_IMPORTED_MODULE_9__.OrganizationIcon,
    PyTorchLogo: _icons_PyTorchLogoIcon__WEBPACK_IMPORTED_MODULE_10__["default"],
    ReactJs: _icons_ReactJsLogoIcon__WEBPACK_IMPORTED_MODULE_11__["default"],
    School: _icons_SchoolIcon__WEBPACK_IMPORTED_MODULE_12__["default"],
    Student: _icons_StudentIcon__WEBPACK_IMPORTED_MODULE_13__["default"],
    TensorFlowLogo: _icons_TensorFlowLogoIcon__WEBPACK_IMPORTED_MODULE_14__["default"],
    Twitter: _icons_TwitterIcon__WEBPACK_IMPORTED_MODULE_15__["default"],
    WebRTC: _icons_WebRTCIcon__WEBPACK_IMPORTED_MODULE_16__["default"],
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (icons);


/***/ })

}]);
//# sourceMappingURL=icons_lib_index_js.5e50ff84ee56795b8851.js.map